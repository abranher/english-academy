module.exports = require("../../postcss.config.cjs")
